const jsonFile = "tweets.json"; // Name of your JSON file

// Function to load tweets from JSON file
function loadTweets() {
  fetch(jsonFile)
    .then(response => response.json())
    .then(data => {
      const allTweets = document.querySelector(".allweets");
      allTweets.innerHTML = ""; // Clear existing tweets

      for (const tweet of data) {
        const tweetDiv = createTweetElement(tweet);
        allTweets.appendChild(tweetDiv);
      }
    })
    .catch(error => console.error("Error loading tweets:", error));
}

// Function to create a single tweet HTML element
function createTweetElement(tweet) {
  const tweetDiv = document.createElement("div");
  tweetDiv.classList.add("tweet");

  const dpDiv = document.createElement("div");
  dpDiv.classList.add("dp");
  const dpImage = document.createElement("image");
  dpImage.classList.add("dp-pic");
  dpImage.src = tweet.profilePic;
  const username = document.createElement("p");
  username.textContent = `@${tweet.username}`;
  dpDiv.appendChild(dpImage);
  dpDiv.appendChild(username);

  const postDiv = document.createElement("div");
  postDiv.classList.add("post");
  const postContent = document.createElement("p");
  postContent.textContent = tweet.content;
  postDiv.appendChild(postContent);

  tweetDiv.appendChild(dpDiv);
  tweetDiv.appendChild(postDiv);

  return tweetDiv;
}

// Function to save tweets to JSON file
function saveTweets(tweets) {
  fetch(jsonFile, {
    method: "POST",
    body: JSON.stringify(tweets),
    headers: { "Content-Type": "application/json" }
  })
    .then(response => {
      if (response.ok) {
        console.log("Tweets saved successfully!");
      } else {
        console.error("Error saving tweets:", response.statusText);
      }
    })
    .catch(error => console.error("Error saving tweets:", error));
}

var config = {
    KEY : '10xw3d7acLWthUx-St9Jz4fp6D2B3xa84-bp398peXao',
    ID : 'AIzaSyCPfKyzDlDGcgZg8sBbDvh6qSuiVuvLFM0'
}

// Load tweets on page load
loadTweets();

// Add event listener to Post Story button
const postStoryButton = document.getElementById("PostStory");
postStoryButton.addEventListener("click", function() {
  const usernameInput = document.getElementById("your-story-id");
  const storyInput = document.getElementById("your-story");

  if (usernameInput.value && storyInput.value) {
    const newTweet = {
      username: usernameInput.value,
      profilePic: "images/dp5.jpg", // Change this to a default profile pic path if needed
      content: storyInput.value
    };

    // Load existing tweets
    fetch(jsonFile)
      .then(response => response.json())
      .then(data => {
        const allTweets = data;
        allTweets.push(newTweet); // Add new tweet to the array

        // Save updated tweets
        saveTweets(allTweets);

        // Clear input fields
        usernameInput.value = "";
        storyInput.value = "";

        // Load updated tweets again (including the new one)
        loadTweets();
      })
      .catch(error => console.error("Error loading tweets for saving:", error));
  } else {
    alert("Please enter both username and your story!");
  }
});


